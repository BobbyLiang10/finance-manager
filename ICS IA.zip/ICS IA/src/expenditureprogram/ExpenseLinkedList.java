package expenditureprogram;

/**
 * This class stores all ExpenseNodes in a custom linked list and allows the Spreadsheet class
 * to modify the linked list based on user input
 * @author Bobby Liang
 *
 */

public class ExpenseLinkedList {

	private ExpenseNode head;
	private ExpenseNode tail;
	private int size = 0;
	
	/**
	 * Method returns the size of the linked list
	 * @return size, the size of the linked list
	 */
	public int getSize() {
		return size;
	}
	
	/**
	 * Method to add a node at the end of the linked list
	 * @param expense, a valid Expense
	 */
	public void addBack (Expense expense) {
		if (head == null) {
			head = new ExpenseNode(expense, null, null);
			tail = head;
		} else {
			ExpenseNode node = new ExpenseNode (expense, null, tail);
			this.tail.setNext(node);
			this.tail = node;
		}
		size++;
	}
	
	/**
	 * Removes the head of the linked list
	 * @return temp, the ExpenseNode corresponding to the head of the linked list
	 */
	public ExpenseNode removeFront() {
		// the linked list is already empty, so null is returned
		if (head == null) {
			return null;
		}
		
		ExpenseNode temp = head;
		head = head.getNext();
		// unlink it from the linked list
		temp.setNext(null);
		// size of linked list decreases by one
		size--;
		return temp;
	}
	
	/**
	 * Method to delete an expense at a specific index
	 * @param i, the index of the specified expense in the linked list
	 */
	public void deleteAt(int i) {
		// if the linked list is empty, nothing happens
		if (head == null) {
			return;
		}
		
		// store the head node
		ExpenseNode temp = head;
		
		if (i == 0) {
			head = temp.getNext();
			return;
		}
		
		// search for the previous node of the node to be deleted
		for (int j = 0; temp != null && j < i-1; j++) {
			temp = temp.getNext();
		}
		
		// if the selected index is more than the number of nodes, nothing is returned
		if (temp == null || temp.getNext() == null) {
			return;
		}
		
		// the ExpenseNode temp.getNext is the selected node to be deleted
		// store the pointer to the next of the ExpenseNode to be deleted
		ExpenseNode next = temp.getNext().getNext();
		
		// unlink the deleted node from the list
		temp.setNext(next);
		// size of the linked list decrements by one
		size--;
	}
	
	

	/**
	 * Method to access an expense given a specific index
	 * @param i, the position of the expense in the linked list
	 * @return current.getExpense(), the expense stored in the ExpenseNode
	 */
	public Expense getExpense(int i) {
		ExpenseNode current = head;
		int count = 0;
		
		while (current != null) {
			if (count == i) {
				return current.getExpense();
			}
			count++;
			current = current.getNext();
		}
		// the user was asking for a non-existent element, so 
		// assert fail
		assert (false);
		return null;
	}
	 
}
