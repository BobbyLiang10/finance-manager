package expenditureprogram;

import java.awt.Font;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.RandomAccessFile;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 * This class displays the login screen when the user launches the program
 * @author Bobby Liang
 *
 */

public class Login extends JFrame {

	// declaration of instance fields
	private JLabel userLabel;
	private JLabel passwordLabel;
	private JLabel title;
	private static JTextField userText;
	private JPasswordField passwordText;
	private JButton loginButton;
	private JButton registerButton;
	private static JPanel loginPanel;
	
	/**
	 * Constructor that sets the design of the login screen
	 */
	public Login() {
		// sets the title, size, and close operation of the window
		super("Expenditures Program");
		setSize(500, 500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		

		// initializing the panel and adding it to the window
		loginPanel = new JPanel();
		loginPanel.setLayout(null);
		add(loginPanel);
		
		// Initializing buttons, text fields, and labels
		title = new JLabel("Login");
		title.setBounds(200, 10, 80, 25);
		title.setFont(new Font("Verdana", 1, 20));

		userLabel = new JLabel("Username");
		userLabel.setBounds(125, 80, 80, 25);

		userText = new JTextField(20);
		userText.setBounds(200, 80, 165, 25);

		passwordLabel = new JLabel("Password");
		passwordLabel.setBounds(125, 160, 80, 25);
	
		// changes the password into dots, hides the password information
		passwordText = new JPasswordField();
		passwordText.setBounds(200, 160, 165, 25);

		registerButton = new JButton("Register");
		registerButton.setBounds(270, 240, 100, 25);
		registerButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// if the user is not registered, then the user is redirected to the register section
				if (!userRegistered()) {
					userText.setText("");
					passwordText.setText("");
					loginPanel.hide();
					Register newUser = new Register();
					// adds the panel onto the JFrame
					add(newUser);
				// otherwise, the user already has an account and can proceed to login
				} else {
					JOptionPane.showMessageDialog(null, "You already registered! \nPlease login.", "User already registered",
							JOptionPane.NO_OPTION);
				}
			}
		});

		loginButton = new JButton("Login");
		loginButton.setBounds(125, 240, 80, 25);
		loginButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// if the username and password match, the login screen will be disposed and the user enters the menu
				if (checkCredentials()) {
					loginPanel.hide();
					new Menu();
					setVisible(false);
				// otherwise, the user entered invalid login credentials
				} else {
					JOptionPane.showMessageDialog(null, "Invalid login credentials! \nPlease try again.", "Login Error",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		
		// adds all text fields, labels, and buttons to the panel
		loginPanel.add(title);
		loginPanel.add(userLabel);
		loginPanel.add(userText);
		loginPanel.add(passwordLabel);
		loginPanel.add(passwordText);
		loginPanel.add(registerButton);
		loginPanel.add(loginButton);

		// sets the frame to be visible
		setVisible(true);
	}

	/**
	 * Method that determines whether the user has registered or not
	 * @return true if the text file exists, false if the text file does not exist
	 */
	public static boolean userRegistered() {
		try {
			final RandomAccessFile users = new RandomAccessFile("users.txt", "rw");
			// if the text file does not exist, then the user has not registered and return false, otherwise return true
			if (users.length() == 0L) {
				return false;
			} else {
				return true;
			}
		} catch (IOException e) {
			e.getMessage();
		}
		return false;
	}

	/**
	 * Method that determines whether the user's username and password match
	 * @return true if the username and password match the credentials saved in the text file, otherwise return false
	 */
	public boolean checkCredentials() {
		boolean loggedIn = false;
		try {
			RandomAccessFile credentials = new RandomAccessFile("users.txt", "r");

			String readFile = credentials.readLine();
			String name = readFile.substring(0, readFile.indexOf("\\"));
			String savedPassword = readFile.substring(readFile.indexOf("\\") + 1);

			String password = "";
			
			// 
			for (int i = 0; i < savedPassword.length(); ++i) {
                int j = savedPassword.charAt(i) + '\u0003';
                password += (char)j;
            }
			
			if (name.equals(userText.getText()) && password.equals(passwordText.getText())) {
				loggedIn = true;
			} else {
				loggedIn = false;
			}
			credentials.close();
		} catch (IOException e) {
			e.getMessage();
		}
		return loggedIn;
	}

	/**
	 * Method for the user to return to the login screen
	 */
	public static void returnToLogin() {
		loginPanel.setVisible(true);
	}

	/**
	 * Accessor method to get the username of the user
	 * @return a String within the userText text field
	 */
	public static String getUsername() {
		return userText.getText();
	}

}
