package expenditureprogram;

/**
 * This class stores the nodes of the ExpenseLinkedList
 * @author Bobby Liang
 *
 */

public class ExpenseNode {

	private ExpenseNode next;
	private ExpenseNode prev;
	private Expense node;
	
	/**
	 * Constructor that creates an expense node and sets the positions in front and behind it
	 * @param node, the expense stored in this node
	 * @param next, the ExpenseNode in front of this node
	 * @param prev, the ExpenseNode behind this node
	 */
	public ExpenseNode(Expense node, ExpenseNode next, ExpenseNode prev) {
		this.node = node;
		this.next = next;
		this.prev = prev;
	}
	
	/**
	 * Modifier method that sets the expense of this node
	 * @param node, the Expense of the current node
	 */
	public void setValue (Expense node) {
		this.node = node;
	}
	
	/**
	 * Modifier method that links the next node to the current one
	 * @param node, the next ExpenseNode
	 */
	public void setNext (ExpenseNode node) {
		next = node;
	}
	
	/**
	 * Modifier method that links the previous node to the current one 
	 * @param node, the previous ExpenseNode
	 */
	public void setPrev (ExpenseNode node) {
		prev = node;
	}
	
	/**
	 * Method that returns the data stored in the ExpenseNode
	 * @return node, the Expense stored in the ExpenseNode
	 */
	public Expense getExpense() {
		return node;
	}
	
	/**
	 * Accessor method that returns the node in front of the current node
	 * @return next, the node in front of a specific node
	 */
	public ExpenseNode getNext() {
		return next;
	}
	
	/**
	 * Accessor method that returns the node behind the current node
	 * @return prev, the node behind a specific node
	 */
	public ExpenseNode getPrev() {
		return prev;
	}
	
}
