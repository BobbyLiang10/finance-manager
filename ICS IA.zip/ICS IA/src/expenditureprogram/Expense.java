package expenditureprogram;

/**
 * This class creates an expense that specifies the name of the expense
 * and how much is spent on this expense every month
 * @author Bobby Liang
 *
 */

public class Expense {

	private String expenseName;
	private double januaryExpenses;
	private double februaryExpenses;
	private double marchExpenses;
	private double aprilExpenses;
	private double mayExpenses;
	private double juneExpenses;
	private double julyExpenses;
	private double augustExpenses;
	private double septemberExpenses;
	private double octoberExpenses;
	private double novemberExpenses;
	private double decemberExpenses;
	
	
	//empty constructor
	public Expense() {
	}
	
	/**
	 * Constructor that creates a new expense with a given name
	 * @param newName, the name of the expense
	 */
	public Expense(String newName) {
		setExpenseName(newName);
	}
	
	/**
	 * Method that sets the name of the expense
	 * @param newName, the name of the expense
	 */
	public void setExpenseName(String newName) {
		expenseName = newName;
	}
	
	/**
	 * Modifier method that sets the expenses spent in January
	 * @param jan, the amount spent in January
	 */
	public void setJanuary(double jan) {
		januaryExpenses = jan;
	}
	
	/**
	 * Modifier method that sets the expenses spent in February
	 * @param feb, the amount spent in February
	 */
	public void setFebruary(double feb) {
		februaryExpenses = feb;
	}
	
	/**
	 * Modifier method that sets the expenses spent in March
	 * @param mar, the amount spent in March
	 */
	public void setMarch(double mar) {
		marchExpenses = mar;
	}
	
	/**
	 * Modifier method that sets the expenses spent in April
	 * @param apr, the amount spent in April
	 */
	public void setApril(double apr) {
		aprilExpenses = apr;
	}
	
	/**
	 * Modifier method that sets the expenses spent in May
	 * @param may, the amount spent in May
	 */
	public void setMay(double may) {
		mayExpenses = may;
	}
	
	/**
	 * Modifier method that sets the expenses spent in June
	 * @param jun, the amount spent in June
	 */
	public void setJune(double jun) {
		juneExpenses = jun;
	}
	
	/**
	 * Modifier method that sets the expenses spent in July
	 * @param jul, the amount spent in July
	 */
	public void setJuly(double jul) {
		julyExpenses = jul;
	}
	
	/**
	 * Modifier method that sets the expenses spent in August
	 * @param aug, the amount spent in August
	 */
	public void setAugust(double aug) {
		augustExpenses = aug;
	}
	
	/**
	 * Modifier method that sets the expenses spent in September
	 * @param sept, the amount spent in September
	 */
	public void setSeptember(double sept) {
		septemberExpenses = sept;
	}
	
	/**
	 * Modifier method that sets the expenses spent in October
	 * @param oct, the amount spent in October
	 */
	public void setOctober(double oct) {
		octoberExpenses = oct;
	}
	
	/**
	 * Modifier method that sets the expenses spent in November
	 * @param nov, the amount spent in November
	 */
	public void setNovember(double nov) {
		novemberExpenses = nov;
	}
	
	/**
	 * Modifier method that sets the expenses spent in December
	 * @param dec, the amount spent in December
	 */
	public void setDecember(double dec) {
		decemberExpenses = dec;
	}
	
	/**
	 * Accessor method that returns the name of the expense
	 * @return expenseName, the name of the expense
	 */
	public String getExpenseName() {
		return expenseName;
	}
	
	/**
	 * Accessor method that returns the money spent in January
	 * @return januaryExpenses, amount spent on expense in January
	 */
	public double getJanuary() {
		return januaryExpenses;
	}
	
	/**
	 * Accessor method that returns the money spent in February
	 * @return februaryExpenses, amount spent on expense in February
	 */
	public double getFebruary() {
		return februaryExpenses;
	}
	
	/**
	 * Accessor method that returns the money spent in March
	 * @return marchExpenses, amount spent on expense in March
	 */
	public double getMarch() {
		return marchExpenses;
	}
	
	/**
	 * Accessor method that returns the money spent in April
	 * @return aprilExpenses, amount spent on expense in April
	 */
	public double getApril() {
		return aprilExpenses;
	}
	
	/**
	 * Accessor method that returns the money spent in May
	 * @return mayExpenses, amount spent on expense in May
	 */
	public double getMay() {
		return mayExpenses;
	}
	
	/**
	 * Accessor method that returns the money spent in June
	 * @return juneExpenses, amount spent on expense in June
	 */
	public double getJune() {
		return juneExpenses;
	}
	
	/**
	 * Accessor method that returns the money spent in July
	 * @return julyExpenses, amount spent on expense in July
	 */
	public double getJuly() {
		return julyExpenses;
	}
	
	/**
	 * Accessor method that returns the money spent in August
	 * @return augustExpenses, amount spent on expense in August
	 */
	public double getAugust() {
		return augustExpenses; 
	}
	
	/**
	 * Accessor method that returns the money spent in September
	 * @return septemberExpenses, amount spent on expense in September
	 */
	public double getSeptember() {
		return septemberExpenses; 
	}
	
	/**
	 * Accessor method that returns the money spent in October
	 * @return octoberExpenses, amount spent on expense in October
	 */
	public double getOctober() {
		return octoberExpenses;
	}
	
	/**
	 * Accessor method that returns the money spent in November
	 * @return novemberExpenses, amount spent on expense in November
	 */
	public double getNovember() {
		return novemberExpenses;
	}
	
	/**
	 * Accessor method that returns the money spent in December
	 * @return decemberExpenses, amount spent on expense in December
	 */
	public double getDecember() {
		return decemberExpenses;
	}
	
	/**
	 * Method that returns the yearly total spent on an expense
	 * @return the sum of all monthly expenses
	 */
	
	public double getYearlyTotal() {
		return januaryExpenses + februaryExpenses + marchExpenses + aprilExpenses + mayExpenses + juneExpenses + julyExpenses
				+ augustExpenses + septemberExpenses + octoberExpenses + novemberExpenses + decemberExpenses;
	}

}
