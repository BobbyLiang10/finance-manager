package expenditureprogram;

import javax.swing.SwingUtilities;

/**
 * This class allows the user to launch and run the program
 * @author Bobby Liang
 *
 */

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new Login();
			}
		});
		
	}

}

