package expenditureprogram;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 * This class allows the user to edit a specific expense in a separate JFrame
 * and updates the original spreadsheet
 * @author Bobby Liang
 *
 */

public class EditExpense extends JFrame {

	// declaration of variables

	JTextField expenseName;
	JTextField expenseJan;
	JTextField expenseFeb;
	JTextField expenseMar;
	JTextField expenseApr;
	JTextField expenseMay;
	JTextField expenseJun;
	JTextField expenseJul;
	JTextField expenseAug;
	JTextField expenseSept;
	JTextField expenseOct;
	JTextField expenseNov;
	JTextField expenseDec;

	JLabel panelTitle;
	JLabel expenseNameLabel;
	JLabel expenseJanLabel;
	JLabel expenseFebLabel;
	JLabel expenseMarLabel;
	JLabel expenseAprLabel;
	JLabel expenseMayLabel;
	JLabel expenseJunLabel;
	JLabel expenseJulLabel;
	JLabel expenseAugLabel;
	JLabel expenseSeptLabel;
	JLabel expenseOctLabel;
	JLabel expenseNovLabel;
	JLabel expenseDecLabel;

	JButton addExpense;
	JButton exitButton;
	
	Expense expense = new Expense();

	/**
	 * Constructor that modifies an expense
	 */
	public EditExpense() {
		setTitle("Edit an expense");
		setLayout(null);
		setSize(500, 500);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		// adding labels
		panelTitle = new JLabel("Edit an Expense");
		panelTitle.setBounds(150, 10, 300, 25);
		panelTitle.setFont(new Font("Verdana", 1, 20));
		add(panelTitle);

		expenseNameLabel = new JLabel("Name of Expense");
		expenseNameLabel.setBounds(75, 50, 300, 25);
		add(expenseNameLabel);

		expenseJanLabel = new JLabel("January Expenses");
		expenseJanLabel.setBounds(75, 80, 300, 25);
		add(expenseJanLabel);

		expenseFebLabel = new JLabel("February Expenses");
		expenseFebLabel.setBounds(75, 110, 300, 25);
		add(expenseFebLabel);

		expenseMarLabel = new JLabel("March Expenses");
		expenseMarLabel.setBounds(75, 140, 300, 25);
		add(expenseMarLabel);

		expenseAprLabel = new JLabel("April Expenses");
		expenseAprLabel.setBounds(75, 170, 300, 25);
		add(expenseAprLabel);

		expenseMayLabel = new JLabel("May Expenses");
		expenseMayLabel.setBounds(75, 200, 300, 25);
		add(expenseMayLabel);

		expenseJunLabel = new JLabel("June Expenses");
		expenseJunLabel.setBounds(75, 230, 300, 25);
		add(expenseJunLabel);

		expenseJulLabel = new JLabel("July Expenses");
		expenseJulLabel.setBounds(75, 260, 300, 25);
		add(expenseJulLabel);

		expenseAugLabel = new JLabel("August Expenses");
		expenseAugLabel.setBounds(75, 290, 300, 25);
		add(expenseAugLabel);

		expenseSeptLabel = new JLabel("September Expenses");
		expenseSeptLabel.setBounds(75, 320, 300, 25);
		add(expenseSeptLabel);

		expenseOctLabel = new JLabel("October Expenses");
		expenseOctLabel.setBounds(75, 350, 300, 25);
		add(expenseOctLabel);

		expenseNovLabel = new JLabel("November Expenses");
		expenseNovLabel.setBounds(75, 380, 300, 25);
		add(expenseNovLabel);

		expenseDecLabel = new JLabel("December Expenses");
		expenseDecLabel.setBounds(75, 410, 300, 25);
		add(expenseDecLabel);

		// adding text fields
		// indicates the length of the text field
		expenseName = new JTextField(20);
		// the location of the text field
		expenseName.setBounds(225, 50, 165, 25);
		add(expenseName);

		// indicates the length of the text field
		expenseJan = new JTextField(20);
		// the location of the text field
		expenseJan.setBounds(225, 80, 165, 25);
		add(expenseJan);

		// indicates the length of the text field
		expenseFeb = new JTextField(20);
		// the location of the text field
		expenseFeb.setBounds(225, 110, 165, 25);
		add(expenseFeb);

		// indicates the length of the text field
		expenseMar = new JTextField(20);
		// the location of the text field
		expenseMar.setBounds(225, 140, 165, 25);
		add(expenseMar);

		// indicates the length of the text field
		expenseApr = new JTextField(20);
		// the location of the text field
		expenseApr.setBounds(225, 170, 165, 25);
		add(expenseApr);

		// indicates the length of the text field
		expenseMay = new JTextField(20);
		// the location of the text field
		expenseMay.setBounds(225, 200, 165, 25);
		add(expenseMay);

		// indicates the length of the text field
		expenseJun = new JTextField(20);
		// the location of the text field
		expenseJun.setBounds(225, 230, 165, 25);
		add(expenseJun);

		// indicates the length of the text field
		expenseJul = new JTextField(20);
		// the location of the text field
		expenseJul.setBounds(225, 260, 165, 25);
		add(expenseJul);

		// indicates the length of the text field
		expenseAug = new JTextField(20);
		// the location of the text field
		expenseAug.setBounds(225, 290, 165, 25);
		add(expenseAug);

		// indicates the length of the text field
		expenseSept = new JTextField(20);
		// the location of the text field
		expenseSept.setBounds(225, 320, 165, 25);
		add(expenseSept);

		// indicates the length of the text field
		expenseOct = new JTextField(20);
		// the location of the text field
		expenseOct.setBounds(225, 350, 165, 25);
		add(expenseOct);

		// indicates the length of the text field
		expenseNov = new JTextField(20);
		// the location of the text field
		expenseNov.setBounds(225, 380, 165, 25);
		add(expenseNov);

		// indicates the length of the text field
		expenseDec = new JTextField(20);
		// the location of the text field
		expenseDec.setBounds(225, 410, 165, 25);
		add(expenseDec);

		addExpense = new JButton("Update Table");
		addExpense.setBounds(75, 440, 125, 25);
		addExpense.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				boolean isExpenseValid = true;
				boolean isEditedClicked = DisplaySpreadsheet.getEditedClicked();
				// checks if user input a name for their expense
				if (expenseName.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Expense Name cannot be left blank. \nPlease try again.",
							"Input Error", JOptionPane.ERROR_MESSAGE);
					isExpenseValid = false;
				} else if (isEditedClicked == false){
					expense.setExpenseName(expenseName.getText());
				} else {
					DisplaySpreadsheet.getSpreadsheet().setValueAt(String.valueOf(expenseName.getText()), DisplaySpreadsheet.getRowIndex(), 0);
				}

				try {
					// checks if user input is a positive double value
					if (Double.parseDouble(expenseJan.getText()) < 0 || Double.parseDouble(expenseFeb.getText()) < 0
							|| Double.parseDouble(expenseJan.getText()) < 0
							|| Double.parseDouble(expenseFeb.getText()) < 0
							|| Double.parseDouble(expenseMar.getText()) < 0
							|| Double.parseDouble(expenseApr.getText()) < 0
							|| Double.parseDouble(expenseMay.getText()) < 0
							|| Double.parseDouble(expenseJun.getText()) < 0
							|| Double.parseDouble(expenseJul.getText()) < 0
							|| Double.parseDouble(expenseAug.getText()) < 0
							|| Double.parseDouble(expenseSept.getText()) < 0
							|| Double.parseDouble(expenseOct.getText()) < 0
							|| Double.parseDouble(expenseNov.getText()) < 0
							|| Double.parseDouble(expenseDec.getText()) < 0) {
						JOptionPane.showMessageDialog(null, "Expenses cannot be a negative number. \nPlease try again.",
								"Input Error", JOptionPane.ERROR_MESSAGE);
						isExpenseValid = false;
						// if the expense already exists but the user wants to change its contents
					} else if (DisplaySpreadsheet.getRowIndex() >= 0 && DisplaySpreadsheet.getEditedClicked() == true) {
						DisplaySpreadsheet.getSpreadsheet().setValueAt(Double.parseDouble(expenseJan.getText()), DisplaySpreadsheet.getRowIndex(), 1);
						DisplaySpreadsheet.getSpreadsheet().setValueAt(Double.parseDouble(expenseFeb.getText()), DisplaySpreadsheet.getRowIndex(), 2);
						DisplaySpreadsheet.getSpreadsheet().setValueAt(Double.parseDouble(expenseMar.getText()), DisplaySpreadsheet.getRowIndex(), 3);
						DisplaySpreadsheet.getSpreadsheet().setValueAt(Double.parseDouble(expenseApr.getText()), DisplaySpreadsheet.getRowIndex(), 4);
						DisplaySpreadsheet.getSpreadsheet().setValueAt(Double.parseDouble(expenseMay.getText()), DisplaySpreadsheet.getRowIndex(), 5);
						DisplaySpreadsheet.getSpreadsheet().setValueAt(Double.parseDouble(expenseJun.getText()), DisplaySpreadsheet.getRowIndex(), 6);
						DisplaySpreadsheet.getSpreadsheet().setValueAt(Double.parseDouble(expenseJul.getText()), DisplaySpreadsheet.getRowIndex(), 7);
						DisplaySpreadsheet.getSpreadsheet().setValueAt(Double.parseDouble(expenseAug.getText()), DisplaySpreadsheet.getRowIndex(), 8);
						DisplaySpreadsheet.getSpreadsheet().setValueAt(Double.parseDouble(expenseSept.getText()), DisplaySpreadsheet.getRowIndex(), 9);
						DisplaySpreadsheet.getSpreadsheet().setValueAt(Double.parseDouble(expenseOct.getText()), DisplaySpreadsheet.getRowIndex(), 10);
						DisplaySpreadsheet.getSpreadsheet().setValueAt(Double.parseDouble(expenseNov.getText()), DisplaySpreadsheet.getRowIndex(), 11);
						DisplaySpreadsheet.getSpreadsheet().setValueAt(Double.parseDouble(expenseDec.getText()), DisplaySpreadsheet.getRowIndex(), 12);
					} else {
					// otherwise, the expense does not exist and needs to be added to the spreadsheet
						expense.setJanuary(Double.parseDouble(expenseJan.getText()));
						expense.setFebruary(Double.parseDouble(expenseFeb.getText()));
						expense.setMarch(Double.parseDouble(expenseMar.getText()));
						expense.setApril(Double.parseDouble(expenseApr.getText()));
						expense.setMay(Double.parseDouble(expenseMay.getText()));
						expense.setJune(Double.parseDouble(expenseJun.getText()));
						expense.setJuly(Double.parseDouble(expenseJul.getText()));
						expense.setAugust(Double.parseDouble(expenseAug.getText()));
						expense.setSeptember(Double.parseDouble(expenseSept.getText()));
						expense.setOctober(Double.parseDouble(expenseOct.getText()));
						expense.setNovember(Double.parseDouble(expenseNov.getText()));
						expense.setDecember(Double.parseDouble(expenseDec.getText()));
					}
				} catch (NumberFormatException e) {
					JOptionPane.showMessageDialog(null,
							"Please enter a number value for the expenses.",
							"Input Error", JOptionPane.ERROR_MESSAGE);
					isExpenseValid = false;
				}

				// if the user clicked on Edit an Expense button, then the expense is updated, close the window afterwards
				if (isExpenseValid && DisplaySpreadsheet.getEditedClicked() == true) {
					DisplaySpreadsheet.setEditedClicked(false);
					JOptionPane.showMessageDialog(null,
							"Expense Successfully Updated!",
							"Expense updated", JOptionPane.INFORMATION_MESSAGE);
					dispose();
				// otherwise the user clicked on Add an Expense, and the expense is added, close the window afterwards
				} else if (isExpenseValid && DisplaySpreadsheet.getEditedClicked() == false) {
					DisplaySpreadsheet.addRowToSpreadsheet(expense);
					JOptionPane.showMessageDialog(null,
							"Expense Successfully Added!",
							"Expense added", JOptionPane.INFORMATION_MESSAGE);
					dispose();
				}
			}
		});
		add(addExpense);

		exitButton = new JButton("Back to Table");
		exitButton.setBounds(265, 440, 125, 25);
		exitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// close the window 
				dispose();
			}
		});
		add(exitButton);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new EditExpense().setVisible(true);
			}
		});
	}

}
