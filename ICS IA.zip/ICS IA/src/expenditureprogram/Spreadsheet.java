package expenditureprogram;

import javax.swing.table.AbstractTableModel;

/**
 * This class displays the expenses in a table, similar to a spreadsheet format
 * @author Bobby Liang
 *
 */

public class Spreadsheet extends AbstractTableModel {

	// testing with column names and cells
	private String[] months = {"Expense Name", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec",
			"Yearly Total" };

	private ExpenseLinkedList list;
	private String sheetName;

	/**
	 * Constructor
	 * Description: Constructs a spreadsheet with a specified name and stores data in a 
	 * custom linked list
	 * @param name, the name of the spreadsheet
	 * @param list, the ExpenseLinkedList where data will be stored
	 * 
	 */
	public Spreadsheet(String name, ExpenseLinkedList list) {
		sheetName = name;
		this.list = list;
	}
	
	/**
	 * Accessor method to return the spreadsheet name
	 * @return sheetName, the name of the spreadsheet
	 */
	public String getSpreadsheetName() {
		return sheetName;
	}
	
	/**
	 * Mutator method to change the spreadsheet name
	 * @param name, the name of the spreadsheet
	 */
	public void setSpreadsheetName(String name) {
		sheetName = name;
	}

	/**
	 * Method to remove a row from the spreadsheet
	 * @param i, the index of the row
	 */
	public void removeExpense(int i) {
		// if the index of the chosen expense is the head of the linked list, use method removeFront()
		if (i == 0) {
			list.removeFront();
		} else {
			list.deleteAt(i);
		}
		fireTableRowsDeleted(i, i);
		fireTableDataChanged();
	}

	
	/**
	 * Method to add a row to the spreadsheet
	 * @param expense, a valid Expense to be added
	 */
	public void addExpense(Expense expense) {
		int row = list.getSize();
		list.addBack(expense);
		fireTableRowsInserted(row, row);
	}
	
	/**
	 * Returns the number of columns in the spreadsheet
	 */
	public int getColumnCount() {
		return months.length;
	}

	/**
	 * Return the number of rows in the spreadsheet
	 */
	public int getRowCount() {
		return list.getSize();
	}

	/** 
	 * Return the names of each column in the spreadsheet
	 * 
	 */
	public String getColumnName(int col) {
		return months[col];
	}

	/**
	 * Change the value of a cell in an expense on the spreadsheet
	 */
	public void setValueAt(Object value, int rowIndex, int colIndex) {
		Expense expense = list.getExpense(rowIndex);
		
		String strValue = String.valueOf(value);
		
		// change this value to the original cell value
		double doubleValue = 0;
		
		if (colIndex == 0) {
			expense.setExpenseName(strValue);
		}
		
		try {
			doubleValue = Double.valueOf(strValue);
		} catch (NumberFormatException e) {
			e.getMessage();
		}
		
		switch (colIndex) {
		case 1:
			  expense.setJanuary(doubleValue);
		case 2:
			  expense.setFebruary(doubleValue);
		case 3:
			  expense.setMarch(doubleValue);
		case 4:
			  expense.setApril(doubleValue);
		case 5:
			  expense.setMay(doubleValue);
		case 6:
			  expense.setJune(doubleValue);
		case 7:
			  expense.setJuly(doubleValue);
		case 8:
			  expense.setAugust(doubleValue);
		case 9:
			  expense.setSeptember(doubleValue);
		case 10:
			  expense.setOctober(doubleValue);
		case 11:
			  expense.setNovember(doubleValue);
		case 12:
			  expense.setDecember(doubleValue);
		}
		fireTableRowsUpdated(rowIndex, colIndex);
	}
	
	/**
	 * Return the object of a cell in the expense
	 */
	public Object getValueAt(int rowIndex, int colIndex) {
		Expense expense = list.getExpense(rowIndex);
		if (expense == null) {
			return null;
		}
		
		switch (colIndex) {
		case 0:
			return expense.getExpenseName();
		case 1:
			return expense.getJanuary();
		case 2:
			return expense.getFebruary();
		case 3:
			return expense.getMarch();
		case 4:
			return expense.getApril();
		case 5:
			return expense.getMay();
		case 6:
			return expense.getJune();
		case 7:
			return expense.getJuly();
		case 8:
			return expense.getAugust();
		case 9:
			return expense.getSeptember();
		case 10:
			return expense.getOctober();
		case 11:
			return expense.getNovember();
		case 12:
			return expense.getDecember();
		case 13:
			return expense.getYearlyTotal();
		default:
			return null;
		}

	}

}
