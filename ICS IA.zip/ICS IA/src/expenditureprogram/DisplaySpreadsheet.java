package expenditureprogram;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.MessageFormat;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableModel;

/**
 * This class displays a spreadsheet that can be modified by the user
 * @author Bobby Liang
 * 
 */

public class DisplaySpreadsheet extends JFrame {

	// declaration and initialization of variables
	
	// dimensions of the window
	private final static int WIDTH = 1180;
	private final static int HEIGHT = 500;
	

	private static Spreadsheet sheet;

	private JLabel spreadsheetNameLabel;
	private JButton addRow;
	private JButton deleteExpense;
	private JButton editExpense;
	private JButton back;
	private JButton save;
	private JButton print;
	private JButton getMonthlyTotals;

	private JTextField janField;
	private JTextField febField;
	private JTextField marField;
	private JTextField aprField;
	private JTextField mayField;
	private JTextField junField;
	private JTextField julField;
	private JTextField augField;
	private JTextField septField;
	private JTextField octField;
	private JTextField novField;
	private JTextField decField;
	private JTextField yearField;

	private static JPanel mainPanel;
	private static JPanel topPanel;
	private static JPanel centerPanel;
	private static JPanel bottomPanel;

	private JTable spreadsheet;

	private static int rowIndex;
	
	private static boolean isEditedClicked;
	private boolean isSpreadsheetSaved = false;
	private static String spreadsheetName;

	// default empty constructor
	public DisplaySpreadsheet() {

	}

	/**
	 * Constructor that displays a spreadsheet
	 * @param sheet, the Spreadsheet to be displayed
	 */
	public DisplaySpreadsheet(Spreadsheet sheet) {
		// initializing the name and size of the JFrame
		super("Expenditures");
		setPreferredSize(new Dimension(WIDTH, HEIGHT));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// declaration of panels
		mainPanel = new JPanel();
		topPanel = new JPanel();
		centerPanel = new JPanel();
		bottomPanel = new JPanel();

		// setting the layout and adding the panels to the main panel
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
		mainPanel.add(topPanel, BorderLayout.NORTH);
		mainPanel.add(centerPanel, BorderLayout.CENTER);
		mainPanel.add(bottomPanel, BorderLayout.SOUTH);

		// get the name of the spreadsheet
		spreadsheetName = sheet.getSpreadsheetName();
		// initialize the spreadsheet that is being displayed
		DisplaySpreadsheet.sheet = sheet;

		// initializing the JTable
		spreadsheet = new JTable(DisplaySpreadsheet.sheet);
		spreadsheet.setPreferredScrollableViewportSize(new Dimension(WIDTH, HEIGHT));
		spreadsheet.setFillsViewportHeight(true);
		// prevents user from dragging columns around
		spreadsheet.getTableHeader().setReorderingAllowed(false);
		// user can only select one row at a time
		spreadsheet.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		// gets the column names of the spreadsheet
		JTableHeader header = spreadsheet.getTableHeader();

		// adding the buttons, labels, and text fields of the panel
		addRow = new JButton("Add an expense.");
		addRow.setBounds(75, 25, 150, 30);
		addRow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// user chooses to add an expense, a new JFrame will pop up to add this expense
				EditExpense edit = new EditExpense();
				edit.setVisible(true);
				edit.setLocationRelativeTo(null);
				edit.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				// the spreadsheet will change and therefore it is not saved
				isSpreadsheetSaved = false;
			}
		});

		editExpense = new JButton("Edit an expense.");
		editExpense.setBounds(95, 25, 150, 30);
		editExpense.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (sheet.getRowCount() == -1) {
					JOptionPane.showMessageDialog(null, "Please select an expense to edit.",
							"Expense not selected", JOptionPane.ERROR_MESSAGE);
				}
				
				// the user chooses to edit an existing expense
				isEditedClicked = true;
				// determines whether the spreadsheet is empty or not, if so, a message will indicate that it is empty
				if (sheet.getRowCount() == 0) {
					JOptionPane.showMessageDialog(null, "There are no expenses in the spreadsheet!",
							"Spreadsheet is empty", JOptionPane.ERROR_MESSAGE);
				// otherwise, the spreadsheet is not empty and a new JFrame will open up
				// the text fields will display the current values for the expenses	
				} else {
					rowIndex = spreadsheet.getSelectedRow();
					EditExpense editedExpense = new EditExpense();
					String expenseName = spreadsheet.getValueAt(rowIndex, 0).toString();
					String janExpense = spreadsheet.getValueAt(rowIndex, 1).toString();
					String febExpense = spreadsheet.getValueAt(rowIndex, 2).toString();
					String marExpense = spreadsheet.getValueAt(rowIndex, 3).toString();
					String aprExpense = spreadsheet.getValueAt(rowIndex, 4).toString();
					String mayExpense = spreadsheet.getValueAt(rowIndex, 5).toString();
					String junExpense = spreadsheet.getValueAt(rowIndex, 6).toString();
					String julExpense = spreadsheet.getValueAt(rowIndex, 7).toString();
					String augExpense = spreadsheet.getValueAt(rowIndex, 8).toString();
					String septExpense = spreadsheet.getValueAt(rowIndex, 9).toString();
					String octExpense = spreadsheet.getValueAt(rowIndex, 10).toString();
					String novExpense = spreadsheet.getValueAt(rowIndex, 11).toString();
					String decExpense = spreadsheet.getValueAt(rowIndex, 12).toString();

					editedExpense.expenseName.setText(expenseName);
					editedExpense.expenseJan.setText(janExpense);
					editedExpense.expenseFeb.setText(febExpense);
					editedExpense.expenseMar.setText(marExpense);
					editedExpense.expenseApr.setText(aprExpense);
					editedExpense.expenseMay.setText(mayExpense);
					editedExpense.expenseJun.setText(junExpense);
					editedExpense.expenseJul.setText(julExpense);
					editedExpense.expenseAug.setText(augExpense);
					editedExpense.expenseSept.setText(septExpense);
					editedExpense.expenseOct.setText(octExpense);
					editedExpense.expenseNov.setText(novExpense);
					editedExpense.expenseDec.setText(decExpense);
					isSpreadsheetSaved = false;

					editedExpense.setVisible(true);
					editedExpense.setLocationRelativeTo(null);
					editedExpense.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				}
			}
		});

		deleteExpense = new JButton("Delete an Expense.");
		deleteExpense.setBounds(400, 25, 150, 30);
		deleteExpense.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				rowIndex = spreadsheet.getSelectedRow();
				// checks if the expense exists in the JTable
				if (rowIndex >= 0) {
					// calls the method that deletes the row at that specific index
					deleteRowAtIndex(rowIndex);
					isSpreadsheetSaved = false;
				// otherwise, the spreadsheet is empty and nothing is deleted
				} else if (sheet.getRowCount() == 0) {
					JOptionPane.showMessageDialog(null,
							"The spreadsheet is empty. There are no more expenses to delete!", "Spreadsheet is empty",
							JOptionPane.ERROR_MESSAGE);
				}
				
				else {
					JOptionPane.showMessageDialog(null,
							"Please select an expense to delete.", "Select an expense.",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		save = new JButton("Save spreadsheet.");
		save.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// save the contents of the spreadsheet/JTable into a text file
				saveSheet();
				// save the spreadsheet name in a text file
				storeSpreadsheetNames();
			}
		});
		
		print = new JButton("Print");
		print.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				print();
			}
		});

		back = new JButton("Back to Menu.");
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// if the spreadsheet is not saved, the user is prompted to reconsider this decision
				// acts as a reminder for them to save their spreadsheet unless otherwise indicated
				if (isSpreadsheetSaved == false) {
					int reply = JOptionPane.showConfirmDialog(null,
							"Your spreadsheet has not been saved. Are you sure you want to leave?",
							"Spreadsheet not saved", JOptionPane.YES_NO_OPTION);
					if (reply == JOptionPane.YES_OPTION) {
						// user indicates that the spreadsheet will not be saved, redirected back to the menu
						new Menu();
						dispose();
					// user chooses to reconsider, nothing happens to the spreadsheet
					} else {
						return;
					}
				// the spreadsheet is confirmed to be saved, and the user can go back to the menu
				} else {
					new Menu();
					dispose();
				}

			}
		});

		getMonthlyTotals = new JButton("Get Monthly Totals");
		getMonthlyTotals.setPreferredSize(new Dimension(150, 20));
		getMonthlyTotals.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// calls the method that sets the text fields to display the monthly/yearly totals of all expenses
				getColumnsTotals();
			}
		});

		spreadsheetNameLabel = new JLabel(spreadsheetName);
		spreadsheetNameLabel.setBounds(65, 10, 400, 25);
		spreadsheetNameLabel.setFont(new Font("Verdana", 1, 20));

		janField = new JTextField(5);
		febField = new JTextField(5);
		marField = new JTextField(5);
		aprField = new JTextField(5);
		mayField = new JTextField(5);
		junField = new JTextField(5);
		julField = new JTextField(5);
		augField = new JTextField(5);
		septField = new JTextField(5);
		octField = new JTextField(5);
		novField = new JTextField(5);
		decField = new JTextField(5);
		yearField = new JTextField(5);
		
		janField.setText("Jan");
		febField.setText("Feb");
		marField.setText("Mar");
		aprField.setText("Apr");
		mayField.setText("May");
		junField.setText("Jun");
		julField.setText("Jul");
		augField.setText("Aug");
		septField.setText("Sept");
		octField.setText("Oct");
		novField.setText("Nov");
		decField.setText("Dec");
		yearField.setText("Year");

		// adding the buttons, text fields, labels and JTable to respective panels
		
		topPanel.add(spreadsheetNameLabel, BorderLayout.NORTH);
		topPanel.add(save);
		topPanel.add(addRow);
		topPanel.add(deleteExpense);
		topPanel.add(editExpense);
		topPanel.add(print);
		topPanel.add(back);

		centerPanel.add(getMonthlyTotals);
		centerPanel.add(janField);
		centerPanel.add(febField);
		centerPanel.add(marField);
		centerPanel.add(aprField);
		centerPanel.add(mayField);
		centerPanel.add(junField);
		centerPanel.add(julField);
		centerPanel.add(augField);
		centerPanel.add(septField);
		centerPanel.add(octField);
		centerPanel.add(novField);
		centerPanel.add(decField);
		centerPanel.add(yearField);
		
		bottomPanel.add(header, BorderLayout.CENTER);
		bottomPanel.add(spreadsheet, BorderLayout.CENTER);

		// adds a scroll pane for the user
		JScrollPane scrollPane = new JScrollPane(spreadsheet, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setVisible(true);
		mainPanel.add(scrollPane, BorderLayout.CENTER);

		// sets the content pane of the window to be the main panel that consists of all other panels and features
		setContentPane(mainPanel);
		pack();
		// displays the window 
		setVisible(true);
	}

	/**
	 * Method that sums up all the monthly and yearly expenses
	 * Prints out the sum as a string in the text field
	 */
	public void getColumnsTotals() {
		int rowCount = spreadsheet.getRowCount();

		double janTotal = 0;
		double febTotal = 0;
		double marTotal = 0;
		double aprTotal = 0;
		double mayTotal = 0;
		double junTotal = 0;
		double julTotal = 0;
		double augTotal = 0;
		double septTotal = 0;
		double octTotal = 0;
		double novTotal = 0;
		double decTotal = 0;
		double yearlyTotal = 0;

		for (int i = 0; i < rowCount; i++) {
			janTotal += Double.parseDouble(spreadsheet.getValueAt(i, 1).toString());
			febTotal += Double.parseDouble(spreadsheet.getValueAt(i, 2).toString());
			marTotal += Double.parseDouble(spreadsheet.getValueAt(i, 3).toString());
			aprTotal += Double.parseDouble(spreadsheet.getValueAt(i, 4).toString());
			mayTotal += Double.parseDouble(spreadsheet.getValueAt(i, 5).toString());
			junTotal += Double.parseDouble(spreadsheet.getValueAt(i, 6).toString());
			julTotal += Double.parseDouble(spreadsheet.getValueAt(i, 7).toString());
			augTotal += Double.parseDouble(spreadsheet.getValueAt(i, 8).toString());
			septTotal += Double.parseDouble(spreadsheet.getValueAt(i, 9).toString());
			octTotal += Double.parseDouble(spreadsheet.getValueAt(i, 10).toString());
			novTotal += Double.parseDouble(spreadsheet.getValueAt(i, 11).toString());
			decTotal += Double.parseDouble(spreadsheet.getValueAt(i, 12).toString());
			yearlyTotal += Double.parseDouble(spreadsheet.getValueAt(i, 13).toString());
		}

		janField.setText(String.valueOf(janTotal));
		febField.setText(String.valueOf(febTotal));
		marField.setText(String.valueOf(marTotal));
		aprField.setText(String.valueOf(aprTotal));
		mayField.setText(String.valueOf(mayTotal));
		junField.setText(String.valueOf(junTotal));
		julField.setText(String.valueOf(julTotal));
		augField.setText(String.valueOf(augTotal));
		septField.setText(String.valueOf(septTotal));
		octField.setText(String.valueOf(octTotal));
		novField.setText(String.valueOf(novTotal));
		decField.setText(String.valueOf(decTotal));
		yearField.setText(String.valueOf(yearlyTotal));

	}

	/**
	 * Adds a new expense to the spreadsheet and JTable
	 * @param newExpense must be declared
	 */
	public static void addRowToSpreadsheet(Expense newExpense) {
		sheet.addExpense(newExpense);
	}


	/**
	 * Deletes an expense from the spreadsheet at a specific index
	 * @param i, the index at which the expense is deleted must be specified
	 */
	public static void deleteRowAtIndex(int i) {
		sheet.removeExpense(i);
	}

	/**
	 * Method that retrieves the row that the user clicked on in the JTable
	 * @return the index of the row that the user selected 
	 */
	public static int getRowIndex() {
		return rowIndex;
	}

	/**
	 * Mutator method that sets whether an expense is edited or not
	 * @param reset, sets isEditedClicked to true or false depending on whether the expense is edited
	 */
	public static void setEditedClicked(boolean reset) {
		isEditedClicked = reset;
	}

	/**
	 * Accessor method that returns the boolean variable isEditedClicked
	 * @return the variable isEditedClicked
	 */
	public static boolean getEditedClicked() {
		return isEditedClicked;
	}

	/**
	 * Accessor method that returns the name of the spreadsheet
	 * @return the variable spreadsheetName
	 */
	public String getSpreadsheetName() {
		return spreadsheetName;
	}
	
	/**
	 * Accessor method that returns the spreadsheet
	 * @return the variable sheet
	 */
	public static Spreadsheet getSpreadsheet() {
		return sheet;
	}
	
	/**
	 * Method that saves the spreadsheet as an Excel file and a text file
	 */
	public void saveSheet() {
		// saving a copy as an Excel file
		boolean ifSaved = false;
		try {
			File tableInExcel = new File(spreadsheetName + ".xls");
			TableModel model = spreadsheet.getModel();
			FileWriter excel = new FileWriter(tableInExcel);
			// writes the column names into Excel
			for (int i = 0; i < model.getColumnCount(); i++) {
				excel.write(model.getColumnName(i) + "\t");
			}
			excel.write("\n");
			// writes a new expense on a new line
			for (int i = 0; i < model.getColumnCount(); i++) {
				for (int j = 0; j < model.getColumnCount(); j++) {
					String data = String.valueOf(model.getValueAt(i, j));
					if (data == "null") {
						data = "";
					}
					excel.write(data + "\t");
				}
				excel.write("\n");
			}
			excel.close();
			ifSaved = true;
		} catch (IOException e) {
			Logger.getLogger(DisplaySpreadsheet.class.getName()).log(Level.SEVERE, null, e);
		}
		// saving a copy as text file, easier to load the spreadsheet
		String filePath = spreadsheetName + ".txt";
		File file = new File(filePath);
		try {
			FileWriter fw = new FileWriter(file);
			BufferedWriter bw = new BufferedWriter(fw);
			for (int i = 0; i < spreadsheet.getRowCount(); i++) {
				for (int j = 0; j < spreadsheet.getColumnCount(); j++) {
					bw.write(String.valueOf(spreadsheet.getValueAt(i, j)));
					// separate each entry with an asterisk
					bw.write("*");
				}
				// new line for a new expense
				bw.newLine();
			}
			bw.close();
			fw.close();
			ifSaved = true;
		} catch (IOException e) {
			Logger.getLogger(DisplaySpreadsheet.class.getName()).log(Level.SEVERE, null, e);
		}
		
		// once the files are saved, display a message to the user that the files are saved
		if (ifSaved) {
			JOptionPane.showMessageDialog(null, "File Successfully Saved!", "File Saved.",
					JOptionPane.INFORMATION_MESSAGE);
			isSpreadsheetSaved = true;
		}
	}
	
	/**
	 * Method that stores the name of the spreadsheet being used
	 */
	public static void storeSpreadsheetNames() {
		boolean alreadyExists = false;
		try {
			// file name is specified
			File file = new File ("listOfSpreadsheets.txt");
			// create the file if the file is not already created
			if (!file.exists()) {
				file.createNewFile();
			}
			
			Scanner scanner = new Scanner (file);
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				// if the spreadsheet name already exists in the file, this text file is not changed
				if (line.equals(spreadsheetName)) {
					alreadyExists = true;
				}
			}
			scanner.close();
			
			if (!alreadyExists) {
				// if the spreadsheet name does not exist, add the name of the spreadsheet to the text file
				FileWriter fw = new FileWriter(file,true);
				BufferedWriter bw = new BufferedWriter(fw);
				PrintWriter pw = new PrintWriter(bw);
				pw.println(spreadsheetName);
				pw.close();
			}
			
		} catch (IOException e) {
			Logger.getLogger(DisplaySpreadsheet.class.getName()).log(Level.SEVERE, null, e);
		}
	}
	
	/**
	 * Method that allows the user to print the given spreadsheet
	 */
	private void print() {
		MessageFormat header = new MessageFormat("Print Expenses");
		try {
			boolean complete = spreadsheet.print(JTable.PrintMode.NORMAL, header, null);
			if (complete) {
				JOptionPane.showMessageDialog(null, "Printing successful!");
			}
		} catch (PrinterException e) {
			JOptionPane.showMessageDialog(null, "Could not print.", "Error", JOptionPane.INFORMATION_MESSAGE);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new DisplaySpreadsheet();

	}

}
