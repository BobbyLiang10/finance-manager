package expenditureprogram;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 * This class displays the main menu of the program once the user has logged in
 * @author Bobby Liang
 *
 */

public class Menu extends JFrame {

	// declaration of variables
	private static JPanel menuPanel;
	private JLabel menuTitle;
	private JLabel userLabel;
	private JButton exitButton;
	private JButton existingSpreadsheetButton;
	private JButton newSpreadsheetButton;
	private static String spreadsheetName;

	/**
	 * Constructor that displays the design and layout of the menu
	 */
	public Menu() {
		super("Expenditures Menu");
		menuPanel = new JPanel();
		this.setSize(500, 500);
		// default close operation
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		// adds the JPanel to the window
		this.add(menuPanel);

		menuPanel.setLayout(null);

		// initialization of labels and buttons
		menuTitle = new JLabel("Expenditures Menu");
		menuTitle.setBounds(145, 10, 400, 25);
		menuTitle.setFont(new Font("Verdana", 1, 20));

		String welcomeMessage = "Welcome " + Login.getUsername() + "!";

		userLabel = new JLabel(welcomeMessage);
		userLabel.setBounds(120, 65, 300, 25);
		userLabel.setFont(new Font("Verdana", 1, 20));

		existingSpreadsheetButton = new JButton("Select Existing Spreadsheet");
		existingSpreadsheetButton.setBounds(25, 110, 200, 50);
		existingSpreadsheetButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// redirects user to new JFrame to choose saved spreadsheets
				if (checkFileExists()) {
					new SpreadsheetSelect();
					dispose();
				// there are no spreadsheets that are saved because the file containing the spreadsheet 
				// names does not exist
				} else {
					JOptionPane.showMessageDialog(null, "You have no saved spreadsheets!",
							"Spreadsheet loading error", JOptionPane.INFORMATION_MESSAGE);
				}
				
			}
		});

		newSpreadsheetButton = new JButton("Create New Spreadsheet");
		newSpreadsheetButton.setBounds(250, 110, 200, 50);
		newSpreadsheetButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				spreadsheetName = JOptionPane.showInputDialog("Enter a name for your spreadsheet:");
				// the spreadsheet name cannot be left blank
				if (spreadsheetName == null || (spreadsheetName != null && ("".equals(spreadsheetName)))) {
					JOptionPane.showMessageDialog(null, "Spreadsheet name cannot be left blank.",
							"Spreadsheet Name Error", JOptionPane.INFORMATION_MESSAGE);
				// the spreadsheet name cannot be the same name as a previously stored spreadsheet
				} else if (checkNameExists(spreadsheetName)){
					JOptionPane.showMessageDialog(null, "This spreadsheet name already exists! \nPlease choose a different name.",
							"Spreadsheet Name Error", JOptionPane.ERROR_MESSAGE);
				} else {
					Spreadsheet sheet = new Spreadsheet(spreadsheetName, new ExpenseLinkedList());
					new DisplaySpreadsheet(sheet);
					dispose();
				}
			}
		});

		exitButton = new JButton("Log out");
		exitButton.setBounds(175, 250, 125, 40);

		exitButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				System.exit(0);
			}
		});

		
		// adding the buttons and labels to the menu panel
		menuPanel.add(menuTitle);
		menuPanel.add(userLabel);
		menuPanel.add(existingSpreadsheetButton);
		menuPanel.add(newSpreadsheetButton);
		menuPanel.add(exitButton);
		this.setVisible(true);

	}

	/**
	 * Checks whether the user input for the spreadsheet name is stored in listOfSpreadsheets.txt
	 * @param name, the name of the spreadsheet
	 * @return true if the spreadsheet name already exists, false otherwise
	 */
	public boolean checkNameExists(String name) {
		try {
			// file name is specified
			File file = new File("listOfSpreadsheets.txt");
			// create the file if the file is not already created
			if (!file.exists()) {
				file.createNewFile();
			}

			Scanner scanner = new Scanner(file);
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				if (line.equals(name)) {
					scanner.close();
					return true;
				}
			}
			scanner.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 * Checks whether the listOfSpreadsheets.txt exists
	 * Useful when the user logs in the first time and does not have any saved spreadsheets
	 * @return true if it does, false otherwise
	 */
	public boolean checkFileExists() {
		// file name is specified
		File file = new File("listOfSpreadsheets.txt");
		// create the file if the file is not already created
		if (!file.exists()) {
			return false;
		} else {
			return true;
		}
	}

	/**
	 * Returns the user input for the spreadsheet name
	 * @return spreadsheetName, the name of the spreadsheet
	 */
	public static String getSpreadsheetName() {
		return spreadsheetName;
	}

	/**
	 * Method that returns the user to the main menu
	 */
	public static void returnToMenu() {
		menuPanel.setVisible(true);
	}

}
