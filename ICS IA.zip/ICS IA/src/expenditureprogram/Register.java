package expenditureprogram;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.RandomAccessFile;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 * This class displays the register section of the program, used only when the user logs into the program 
 * without an account
 * @author Bobby Liang
 *
 */

public class Register extends JPanel {

	private static boolean isRegistered = false;
	
	// text field declaration
	private static JTextField userText;
	private static JPasswordField passwordText;
	
	// button declaration
	private static JButton register;
	private static JButton back;
	
	// label declaration
	private static JLabel userLabel;
	private static JLabel passwordLabel;
	private static JLabel title;
	
	// string declaration
	private String username;
	private String password;
	
	/**
	 * Constructor that sets the layout of the Register class
	 */
	public Register() {
		super(new BorderLayout());
		
		// adds title to the middle of the panel
		title = new JLabel("Account Registration");
		title.setBounds(125, 10, 300, 25);
		title.setFont(new Font ("Verdana", 1, 20));
		add(title);
		
		// sets title and location of username
		userLabel = new JLabel("Create a username");
		userLabel.setBounds(75, 80, 300, 25);
		// adds the label onto the panel
		add(userLabel);
		
		// indicates the length of the text field
		userText = new JTextField(20);
		// the location of the text field
		userText.setBounds(200,80,165,25);
		add(userText);
		
		// initializing password label
		passwordLabel = new JLabel("Create a password");
		passwordLabel.setBounds(75, 160, 300, 25);
		add(passwordLabel);
		
		// changes the password into dots, hides the password information
		passwordText = new JPasswordField();
		passwordText.setBounds(200, 160, 165, 25);
		add(passwordText);
		
		// register button
		register = new JButton ("Register");
		register.setBounds(270, 240, 100, 25);
		add(register);
		// once the register button is clicked, calls on the createAccount method
		register.addActionListener (new ActionListener() {
			public void actionPerformed (ActionEvent e) {
				if (userText.getText().equals("") || passwordText.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Username and password fields cannot be left blank. \nPlease try again.", "Login Error",
							JOptionPane.ERROR_MESSAGE);
				} else {
					createAccount();
					if (isRegistered = true) {
						hide();
						Login.returnToLogin();
					}
				}
			}
		});
		
		// back button to return to the login screen
		back = new JButton ("Back to Login");
		back.setBounds(75, 240, 125, 25);
		add(back);
		back.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent e) {
				hide();
				Login.returnToLogin();
			}
		});
		
		setLayout(null);
	}
	
	/**
	 * Method to create an account for the user
	 */
	public void createAccount() {
		// gets the user input in the username and password text fields
		String username = userText.getText();
		String password = passwordText.getText();
		String modifiedPassword = "";
		
		//String savedCredentials = "";
		try {
			// creates a new text file storing the user's credentials
			RandomAccessFile credentials = new RandomAccessFile("users.txt", "rw");
			for (int i = 0; i < password.length(); ++i) {
                // encodes the password using the Caesar cipher by shifting characters of password back three letters
				int k = password.charAt(i) - '\u0003';
                modifiedPassword += (char)k;
            }
			credentials.writeBytes(username + "\\" + modifiedPassword + "\n"); 
			credentials.writeBytes("");
		} catch (IOException e) {
			System.out.println("Error with saving file.");
			isRegistered = false;
		}
		userText.setText("");
		passwordText.setText("");
		JOptionPane.showMessageDialog(null, "Account successfully created. You will be redirected to the login page.", "Account succesfully created",
				JOptionPane.INFORMATION_MESSAGE);
		isRegistered = true;
		
	}
	
}
