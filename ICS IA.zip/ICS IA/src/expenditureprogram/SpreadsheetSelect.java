package expenditureprogram;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

/**
 * This class displays a frame where the user can select previously stored spreadsheets of expenses
 * @author Windows
 *
 */

public class SpreadsheetSelect extends JFrame {

	private JButton back;
	private JLabel existingLabel;
	private static JPanel mainPanel;	
	
	private String [] array;
	
	/**
	 * Constructor that displays the layout of the JFrame and panel
	 */
	public SpreadsheetSelect() {
		// sets the title of the JFrame
		super("Existing Spreadsheets.");
		// sets the size of the window
		setSize(500, 500);
		// default close operation
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		// the window cannot be resized
		setResizable(false);
		mainPanel = new JPanel();
		mainPanel.setLayout(new GridBagLayout());
		
		back = new JButton ("Back to Menu.");
		//back.setBounds(350, 10, 125, 25);
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// if the back button is pressed, user directed back to the menu and this frame closes
				dispose();
				new Menu();
			}
		});
		
		// adds the labels and buttons to the panel
		initJComponents();
		
		// adds the vertical scroll pane to the panel and window
		JScrollPane scrollPane = new JScrollPane(mainPanel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, 
		        JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		this.add(scrollPane);
		
		
		// sets the JFrame to be visible
		setVisible(true);
	}
	
	/**
	 * Method that initializes all buttons and their layout and adds them to the main panel
	 */
	public void initJComponents() {
		// initializing the GridBagConstraints and adding components to it
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.anchor = GridBagConstraints.NORTH;
		gbc.fill = GridBagConstraints.VERTICAL;
		
		gbc.gridx = 1;
		gbc.gridy = 0;
		
		// adding the label to the GridBagConstraint and JPanel
		existingLabel = new JLabel ("Existing Spreadsheets");
		existingLabel.setFont(new Font("Verdana", 1, 20));
		mainPanel.add(existingLabel, gbc);
		gbc.insets = new Insets(10,10,10,10);
		gbc.gridx--;
		
		// adding the back button to the panel
		mainPanel.add(back, gbc);
		
		// calls the method that parses the text file where all spreadsheet names are stored
		// and initializes a String array to contain the spreadsheet names
		addButtonsSpreadsheets();
		gbc.gridwidth = 2;
		
		for(int i = 0; i < array.length; i++) {
			// add a new button for each spreadsheet name
			JButton button = new JButton (array[i]);
			int temp = i;
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					// when button is clicked, load the spreadsheet and dispose the window
					loadSpreadsheet(array[temp]);
					dispose();
				}
			});
		gbc.gridy++;
		// adds the buttons to the screen
		mainPanel.add(button, gbc);
		}
	}
	
	/**
	 * Method that stores the spreadsheet names from the text file into a String array
	 * The array should be initialized after this method call
	 */
	private void addButtonsSpreadsheets() {
		// local variable that counts the number of lines in the listOfSpreadsheets text file
		int counter = 0;
		File spreadsheetNames = new File ("listOfSpreadsheets.txt");
		try {
			FileReader fr = new FileReader(spreadsheetNames);
			BufferedReader br = new BufferedReader(fr);
			String line = br.readLine();
			while (line != null) {
				// determines the number of spreadsheet names in the text file
				counter++;
				line = br.readLine();
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		// creates new array to store the spreadsheet names in the program
		array = new String[counter];
		// reset the counter to initialize the contents in the array
		counter = 0;
		// reads the file again
		File spreadsheetNames2 = new File ("listOfSpreadsheets.txt");
		try {
			FileReader fr = new FileReader(spreadsheetNames2);
			BufferedReader br = new BufferedReader(fr);
			String line = br.readLine();
			while (line != null) {
				// store the spreadsheet names into an array
				array[counter] = line;
				counter++;
				line = br.readLine();
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Loads the spreadsheet that the user chooses to click
	 * @param sheetName, the name of the spreadsheet
	 * On button click, the saved spreadsheet will be displayed
	 */
	private void loadSpreadsheet(String sheetName) {
		// creates a new spreadsheet displaying the saved information
		Spreadsheet sheet = new Spreadsheet(sheetName, new ExpenseLinkedList());
		new DisplaySpreadsheet(sheet);
		String filePath = sheetName + ".txt";
		
		File file = new File(filePath);

		try {
			FileReader fr = new FileReader(file);
			BufferedReader br = new BufferedReader(fr);
			Object [] lines = br.lines().toArray();
			
			for (int i = 0; i < lines.length; i++) {
				String [] parts = lines[i].toString().split("\\*");
				Expense loadExpense = new Expense();
				loadExpense.setExpenseName(parts[0]);
				for (int j = 1; j < parts.length; j++) {
					switch (j) {
					case 1:
						loadExpense.setJanuary(Double.parseDouble(parts[j]));
					case 2:
						loadExpense.setFebruary(Double.parseDouble(parts[j]));
					case 3:
						loadExpense.setMarch(Double.parseDouble(parts[j]));
					case 4:
						loadExpense.setApril(Double.parseDouble(parts[j]));
					case 5:
						loadExpense.setMay(Double.parseDouble(parts[j]));
					case 6:
						loadExpense.setJune(Double.parseDouble(parts[j]));
					case 7:
						loadExpense.setJuly(Double.parseDouble(parts[j]));
					case 8:
						loadExpense.setAugust(Double.parseDouble(parts[j]));
					case 9:
						loadExpense.setSeptember(Double.parseDouble(parts[j]));
					case 10:
						loadExpense.setOctober(Double.parseDouble(parts[j]));
					case 11:
						loadExpense.setNovember(Double.parseDouble(parts[j]));
					case 12:
						loadExpense.setDecember(Double.parseDouble(parts[j]));
					}
				}
				sheet.addExpense(loadExpense);
			}
			br.close();

		} catch (IOException ex) {
			Logger.getLogger(DisplaySpreadsheet.class.getName()).log(Level.SEVERE, null, ex);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SpreadsheetSelect frame = new SpreadsheetSelect();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}

}